---
name: Bug fix
about: For openpilot bug fixes
title: ''
labels: 'bugfix'
assignees: ''
---

**Description**

<!-- A description of the bug and the fix. Also link the issue if it exists. -->

**Verification**

<!-- Explain how you tested this bug fix. -->
