#pragma once

#include <cstdint>

bool watchdog_kick(uint64_t ts);
