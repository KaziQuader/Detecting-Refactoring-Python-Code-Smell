#!/usr/bin/bash
set -e

RUBYOPT="-W0" irqtop -d1 -R
