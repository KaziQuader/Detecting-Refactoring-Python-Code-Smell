#!/usr/bin/bash

DEST=tici:/data/openpilot/selfdrive/debug/profiling/perfetto

scp tici:/data/openpilot/selfdrive/debug/profiling/perfetto/trace_* .
