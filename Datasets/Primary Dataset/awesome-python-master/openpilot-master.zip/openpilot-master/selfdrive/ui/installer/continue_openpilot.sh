#!/usr/bin/bash

cd /data/openpilot
exec ./launch_openpilot.sh
